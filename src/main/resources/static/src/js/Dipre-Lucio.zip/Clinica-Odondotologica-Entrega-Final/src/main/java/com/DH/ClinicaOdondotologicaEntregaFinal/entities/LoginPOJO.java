package com.DH.ClinicaOdondotologicaEntregaFinal.entities;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class LoginPOJO {
    String password;
    Long id;
}
