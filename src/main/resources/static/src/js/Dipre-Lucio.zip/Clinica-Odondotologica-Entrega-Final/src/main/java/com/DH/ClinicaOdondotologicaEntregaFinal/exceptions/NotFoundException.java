package com.DH.ClinicaOdondotologicaEntregaFinal.exceptions;

public class NotFoundException extends Exception{
    public NotFoundException(String message){
        super(message);
    }
}
