package com.DH.ClinicaOdondotologicaEntregaFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaOdondotologicaEntregaFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
