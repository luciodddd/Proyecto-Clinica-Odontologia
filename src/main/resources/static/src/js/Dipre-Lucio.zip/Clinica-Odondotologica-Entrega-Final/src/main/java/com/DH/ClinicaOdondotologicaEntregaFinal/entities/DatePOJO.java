package com.DH.ClinicaOdondotologicaEntregaFinal.entities;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@ToString
public class DatePOJO {
    Date minDate;
    Date maxDate;
}
